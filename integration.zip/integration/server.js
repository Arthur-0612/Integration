const express = require('express');
const jwt = require('jsonwebtoken');
const oracledb = require('oracledb');
const axios = require('axios');
const cors = require('cors');

const app = express();
const port = 3000;

oracledb.initOracleClient({ libDir: '/opt/oracle/instantclient_19_19' });
app.use(cors());

app.use(express.static('public'));

const dbConfig = {
    user: 'dbamv',
    password: 'mvtreina',
    connectString: '172.20.40.218:1521/pdbtrnmv'
};

app.get('/redirect1/:documentNumber', (req, res) => {
    const documentNumber = req.params.documentNumber;

    res.redirect(`/views/redirects/integration1.html?filename=${documentNumber}`);
});

app.get('/redirect2/:documentNumber', (req, res) => {
    const documentNumber = req.params.documentNumber;

    res.redirect(`/views/redirects/integration2.html?filename=${documentNumber}`);
});

//INTEGRAÇÃO INOVAPAR
app.get('/integration1/:document', async (req, res) => {
    let token = req.headers['authorization'];
    const documentNumber = req.params.document; 

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    const isValid = await validateToken(token);
    if (isValid) {
        if (token.startsWith('Bearer ')) {
            token = token.slice(7, token.length).trim();
        }

        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentResponsaNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);

            const cdPacienteResult = await findCdPaciente(connection, documentNumber);

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];

                await findUrl(connection, cdPaciente, res);

                const { url } = await findUrl(connection, cdPaciente, res);
                if (url) {
                    return res.json(url);
                }
            } else if (cdPacienteResult.length === 0) {
                console.log('Document responsa:', documentResponsaNumber);
                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, documentResponsaNumber);
                
                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult[0][0];

                    const cdPacienteResult = await findCdPacienteAtendimento(connection, cdAtendimento);

                    if (cdPacienteResult.length > 0) {
                        const cdPaciente = cdPacienteResult[0][0];

                        const { url } = await findUrl(connection, cdPaciente, res);
                        if (url) {
                            return res.json(url);
                        }
                    } else {
                        return res.status(404).send('Paciente não encontrado para o atendimento fornecido');
                    }
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } else {
        return res.status(401).send('Token inválido');
    }
});

//INTEGRAÇÃO NILO
app.get('/integration2/:document', async (req, res) => {
    let token = req.headers['authorization'];
    const documentNumber = req.params.document; 

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    const isValid = await validateToken(token);
    if (isValid) {
        if (token.startsWith('Bearer ')) {
            token = token.slice(7, token.length).trim();
        }
        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentResponsaNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);

            const cdPacienteResult = await findCdPaciente(connection, documentNumber);

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];

                const { url } = await findUrlNilo(connection, cdPaciente, res);

                if (url) {
                    return res.json(url);
                }
            } else if (cdPacienteResult.length === 0) {
                console.log('Document responsa:', documentResponsaNumber);
                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, documentResponsaNumber);
                
                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult[0][0];

                    const cdPacienteResult = await findCdPacienteAtendimento(connection, cdAtendimento);

                    if (cdPacienteResult.length > 0) {
                        const cdPaciente = cdPacienteResult[0][0];

                        const { url } = await findUrlNilo(connection, cdPaciente, res);

                        if (url) {
                            return res.json(url);
                        }
                    } else {
                        return res.status(404).send('Paciente não encontrado para o atendimento fornecido');
                    }
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } else {
        return res.status(401).send('Token inválido');
    }
});

//INTEGRAÇÃO MEVO
app.get('/integration3/:document', async (req, res) => {
    let token = req.headers['authorization'];
    const documentNumber = req.params.document; 

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    const isValid = await validateToken(token);
    if (isValid) {
        if (token.startsWith('Bearer ')) {
            token = token.slice(7, token.length).trim();
        }

        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentResponsaNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);
            const cdPacienteResult = await findCdPaciente(connection, documentNumber);

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];
                
                const cdAtendimento = await findCdAtendimento(connection, cdPaciente);

                if (cdAtendimento.length > 0) {
                    const atendimentos = cdAtendimento.map(row => row[0]);

                    const urls = [];
                    for (const cdAtendimento of atendimentos) {
                        const urlResult = await findUrlList(connection, cdAtendimento);
                        if (urlResult) {
                            urls.push(urlResult);
                        }
                    }
                    if (urls.length > 0) {
                        return res.json(urls);
                    } else {
                        return res.status(404).send('URLs não encontradas');
                    }
                } 
            } else if (cdPacienteResult.length === 0) {

                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, documentResponsaNumber);

                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult;

                    if (cdAtendimento.length > 0) {
                        const atendimentos = cdAtendimento.map(row => row[0]);
                        console.log("atendimentos", atendimentos)
                        const urls = [];
                        for (const cdAtendimento of atendimentos) {
                            const urlResult = await findUrlListV2(connection, cdAtendimento);
                            if (urlResult) {
                                urls.push(urlResult);
                            }
                        }
                        if (urls.length > 0) {
                            return res.json(urls);
                        } else {
                            return res.status(404).send('URLs não encontradas');
                        }
                    }                    
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
                           
            
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } else {
        return res.status(401).send('Token inválido');
    }
});

app.get('/integration3/mostrar-pdf/:cdAtendimento/:tipoDocumento', async (req, res) => {
    const { cdAtendimento, tipoDocumento } = req.params;

    const urlReceita = 'receita';
    const urlAtestado = 'atestado';
    const urlEncaminhamento = 'encaminhamento';
    const urlExame = 'exame';
    const urlRelatorio = 'relatorio';

    try {
        const connection = await oracledb.getConnection(dbConfig);

        const urlList = await findUrlList(connection, cdAtendimento);

        if (tipoDocumento === urlReceita) {
            if (urlList.urlReceita) {
                res.setHeader('Content-Type', 'application/pdf');
                res.setHeader('Content-Disposition', 'inline; filename="receita.pdf"');
                res.end(urlList.urlReceita); 
            } else {
                res.status(200).send('PDF de Receita não encontrado');
            }
        } else if (tipoDocumento === urlAtestado) {
            if (urlList.urlAtestado) {
                res.setHeader('Content-Type', 'application/pdf');
                res.setHeader('Content-Disposition', 'inline; filename="atestado.pdf"');
                res.end(urlList.urlAtestado);
            } else {
                res.status(200).send('PDF de Atestado não encontrado');
            }
        } else if (tipoDocumento === urlEncaminhamento) {
            if (urlList.urlEncaminhamento) {
                res.setHeader('Content-Type', 'application/pdf');
                res.setHeader('Content-Disposition', 'inline; filename="encaminhamento.pdf"');
                res.end(urlList.urlEncaminhamento);
            } else {
                res.status(200).send('PDF de Encaminhamento não encontrado');
            }
        } else if (tipoDocumento === urlExame) {
            if (urlList.urlExame) {
                res.setHeader('Content-Type', 'application/pdf');
                res.setHeader('Content-Disposition', 'inline; filename="exame.pdf"');
                res.end(urlList.urlExame);
            } else {
                res.status(200).send('PDF de Exame não encontrado');
            }
        } else if (tipoDocumento === urlRelatorio) {
            if (urlList.urlRelatorio) {
                res.setHeader('Content-Type', 'application/pdf');
                res.setHeader('Content-Disposition', 'inline; filename="relatorio.pdf"');
                res.end(urlList.urlRelatorio);
            } else {
                res.status(200).send('PDF de Relatório não encontrado');
            }
        } else {
            res.status(400).send('Tipo de documento inválido');
        }

    } catch (error) {
        res.status(500).send('Erro ao processar o PDF');
        console.error(error);
    }
});


app.get('/integration3/listaatendimentos/1', async (req, res) => {
    let token = req.headers['authorization'];

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    try {
        const isValid = await validateToken(token);
        if (!isValid) {
            return res.status(401).send('Token inválido');
        }

        if (token.startsWith('Bearer ')) {
            token = token.slice(7, token.length).trim();
        }

        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);

            const cdPacienteResult = await findCdPacienteId(connection, "577905");

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];
                const cdAtendimento = await findCdAtendimentoAndData(connection, cdPaciente);

                if (cdAtendimento.length > 0) {
                    const atendimentos = cdAtendimento.map(row => ({
                        cdAtendimento: row[0],
                        dtAtendimento: row[1]
                    }));

                    return res.json(atendimentos);
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            } else {
                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, "32463075805");

                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult[0][0]; 

                    const atendime = await findCdAtendimentoAndData(connection, cdAtendimento);

                    const atendimentos = atendime.map(row => ({
                        cdAtendimento: row[0],
                        dtAtendimento: row[1]
                    }));

                    return res.json(atendimentos);
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } catch (err) {
        console.error('Erro ao validar o token:', err);
        return res.status(401).send('Token inválido');
    }
});

async function validateToken(token) {
    try {
        const response = await axios.get('https://prod.globalhealth.mv/uaa/validate/token', {
            headers: {
                'Authorization': `${token}`
            }
        });
        return response.status === 204;
    } catch (error) {
        console.error('Erro na validação do token:', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdPacienteId(connection, cdPaciente) {
    const sqlPaciente = 'SELECT CD_PACIENTE FROM PACIENTE WHERE CD_PACIENTE = :cdPaciente';
    console.log('Executing SQL:', sqlPaciente);

    const resultPaciente = await connection.execute(sqlPaciente, { cdPaciente });
    console.log('Query Result:', resultPaciente.rows);

    return resultPaciente.rows;
}

async function findCdAtendimentoResponsa(connection, nrCpf) {
    try {
        const sqlParents = 'SELECT CD_ATENDIMENTO FROM RESPONSA WHERE nr_cpf = :nrCpf';
        console.log('Executing SQL:', sqlParents);

        const resultParents = await connection.execute(sqlParents, { nrCpf });
        console.log('Query Result:', resultParents.rows);

        return resultParents.rows;
    } catch (error) {
        console.error('Erro na validação do token:', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdPacienteAtendimento(connection, cdAtendimento) {
    try {
        const sqlCdPacienteAtendimento = 'SELECT CD_PACIENTE FROM ATENDIME WHERE CD_ATENDIMENTO = :cdAtendimento';
        console.log('Executing SQL:', sqlCdPacienteAtendimento, { cdAtendimento });

        const resultCdAtendimento = await connection.execute(sqlCdPacienteAtendimento, { cdAtendimento });
        console.log('Query Result:', resultCdAtendimento.rows);

        return resultCdAtendimento.rows;
    } catch (error) {
        console.error('Paciente não encontrado!', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdPaciente(connection, nrCpf) {
    try {
        const sqlParents = 'SELECT CD_PACIENTE FROM PACIENTE WHERE nr_cpf = :nrCpf';
        console.log('Executing SQL:', sqlParents, { nrCpf });

        const resultParents = await connection.execute(sqlParents, { nrCpf });
        console.log('Query Result:', resultParents.rows);

        return resultParents.rows;
    } catch (error) {
        console.error('Paciente não encontrado!', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdAtendimento(connection, cdPaciente) {
    try {
        const sqlCdAtendimento = 'SELECT CD_ATENDIMENTO FROM ATENDIME WHERE CD_PACIENTE = :cdPaciente';
        console.log('Executing SQL:', sqlParents, { cdPaciente });

        const resultCdAtendimentos = await connection.execute(sqlCdAtendimento, {cdPaciente});
        console.log('Query Result:', resultCdAtendimentos.rows);

        return resultCdAtendimentos.rows;
    } catch (error) {
        console.error('Paciente não encontrado!', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdAtendimentoAndData(connection, cdPaciente) {
    try {
        const sqlcdAtendimentoAndData = 'SELECT CD_ATENDIMENTO, DT_ATENDIMENTO FROM ATENDIME WHERE CD_PACIENTE = :cdPaciente';
        console.log('Executing SQL:', sqlcdAtendimentoAndData, { cdPaciente });

        const resultCdAtendimentoAndData = await connection.execute(sqlcdAtendimentoAndData, { cdPaciente });
        console.log('Query Result:', resultCdAtendimentoAndData.rows);

        return resultCdAtendimentoAndData.rows;
    } catch (error) {
        console.error('Erro ao buscar atendimentos:', error.message);
        return false;
    }
}

async function findUrlNilo(connection, cdPaciente, res) {
    try {
        const sql = `
            SELECT * 
            FROM DBAMV.PW_CASO_PROTOCOLO 
            WHERE CD_ALERTA_PROTOCOLO IN (81, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112)
            AND CD_PACIENTE = :cdPaciente`;
        console.log('Executing SQL:', sql);

        const result = await connection.execute(sql, { cdPaciente });
        console.log('Query Result:', result.rows);

        if (result.rows.length > 0) {

            const url = `https://stg.nilosaude.app/agenda/%7B%7BidPaciente%7D%7D/agendar?selected=true&embedded=true`;

            return res.json(url);
        } else {
            return res.status(404).send('Recurso não disponível no momento para o seu perfil');
        }
    } catch (error) {
        console.error('Erro ao buscar URL:', error.message);
        return res.status(500).send('Erro ao buscar URL');
    }
}


async function findUrl(connection, cdPaciente, res) {
    try {
        const sql2 = `
            SELECT CD_PACIENTE, TO_CHAR(DT_ATENDIMENTO, 'dd') || TO_CHAR(DT_ATENDIMENTO, 'MM') || TO_CHAR(DT_ATENDIMENTO, 'RRRR') || CD_ATENDIMENTO AS senha 
            FROM atendime WHERE CD_PACIENTE = :cdPaciente
        `;
        console.log('Executing SQL:', sql2);

        const result2 = await connection.execute(sql2, { cdPaciente });
        console.log('Query Result:', result2.rows);

        if (result2.rows.length > 0) {
            const firstResult = result2.rows[0];
            const senha = firstResult[1];

            const url = `https://resultadosdeexames.sabara.com.br/vedocs/public/laudo.action?protocolo=${cdPaciente}&senha=${senha}&origem=1&acessoExterno=true`;

            return res.json(url);
        } else {
            return res.status(404).send('Dados não encontrados para o paciente');
        }
    } catch (error) {
        console.error('Erro ao buscar URL:', error.message);
        return res.status(500).send('Erro ao buscar URL');
    }
}

async function clobToBase64(clob) {
    return new Promise((resolve, reject) => {
        if (clob === null) {
            resolve(null);
        }

        let clobData = '';
        clob.setEncoding('utf8'); 

        clob.on('data', (chunk) => {
            clobData += chunk; 
        });

        clob.on('end', () => {
            resolve(clobData); 
        });

        clob.on('error', (err) => {
            reject(err);
        });
    });
}

async function findUrlListV2(connection, cdAtendimento) {
    try {
        const sqlUrlList = `
    SELECT at.CD_ATENDIMENTO, 
           at.DT_ATENDIMENTO, 
           pn.PDF_RETORNO_RECEITA, 
           pn.PDF_RETORNO_ATESTADO, 
           pn.PDF_RETORNO_EXAME, 
           pn.PDF_RETORNO_ENCAMINHAMENTO, 
           pn.PDF_RETORNO_RELATORIO
    FROM nexodata.PRESC_NEXODATA pn
    JOIN atendime at ON at.CD_ATENDIMENTO = pn.CD_ATENDIMENTO
    WHERE pn.CD_ATENDIMENTO = :cdAtendimento`;

        console.log('Executing SQL:', sqlUrlList, { cdAtendimento });

        const result = await connection.execute(sqlUrlList, { cdAtendimento: cdAtendimento });

        console.log('Query Result:', result.rows);

        if (result.rows.length > 0) {
            const row = result.rows[0]; // Assumindo que a primeira linha contém os dados
            const cdAtendimento = row[0]; // at.CD_ATENDIMENTO
            const dtAtendimento = row[1]; // at.DT_ATENDIMENTO
            const clobReceita = row[2]; // pn.PDF_RETORNO_RECEITA
            const clobAtestado = row[3]; // pn.PDF_RETORNO_ATESTADO
            const clobExame = row[4]; // pn.PDF_RETORNO_EXAME
            const clobEncaminhamento = row[5]; // pn.PDF_RETORNO_ENCAMINHAMENTO
            const clobRelatorio = row[6]; // pn.PDF_RETORNO_RELATORIO

            const urlReceita = clobReceita ? await clobToBase64V2(clobReceita) : null;
            const urlAtestado = clobAtestado ? await clobToBase64V2(clobAtestado) : null;
            const urlExame = clobExame ? await clobToBase64V2(clobExame) : null;
            const urlEncaminhamento = clobEncaminhamento ? await clobToBase64V2(clobEncaminhamento) : null;
            const urlRelatorio = clobRelatorio ? await clobToBase64V2(clobRelatorio) : null;

            return {
                cdAtendimento,
                dtAtendimento,
                urlReceita,
                urlAtestado,
                urlExame,
                urlEncaminhamento,
                urlRelatorio
            };
        } else {
            return {
                cdAtendimento,
                dtAtendimento,
                urlReceita: null,
                urlAtestado: null,
                urlExame: null,
                urlEncaminhamento: null,
                urlRelatorio: null
            };
        }
    } catch (error) {
        console.error('Erro ao buscar URLs:', error.message);
        return false;
    }
}

async function clobToBase64V2(clob) {
    return new Promise((resolve, reject) => {
        if (!clob) {
            resolve(null);
            return;
        }

        let clobData = '';
        clob.setEncoding('utf8'); 

        clob.on('data', (chunk) => {
            clobData += chunk; 
        });

        clob.on('end', () => {
            resolve(clobData); 
        });

        clob.on('error', (err) => {
            reject(err);
        });
    });
}

async function findUrlList(connection, cdAtendimento) {
    try {
        const sqlUrlList = `
    SELECT at.CD_ATENDIMENTO, 
           at.DT_ATENDIMENTO, 
           pn.PDF_RETORNO_RECEITA, 
           pn.PDF_RETORNO_ATESTADO, 
           pn.PDF_RETORNO_EXAME, 
           pn.PDF_RETORNO_ENCAMINHAMENTO, 
           pn.PDF_RETORNO_RELATORIO
    FROM nexodata.PRESC_NEXODATA pn
    JOIN atendime at ON at.CD_ATENDIMENTO = pn.CD_ATENDIMENTO
    WHERE pn.CD_ATENDIMENTO = :cdAtendimento`;

console.log('Executing SQL:', sqlUrlList, { cdAtendimento });

const result = await connection.execute(sqlUrlList, { cdAtendimento: cdAtendimento });


        console.log('Query Result:', result.rows);

        if (result.rows.length > 0) {
            let [clobReceita, clobAtestado, clobExame, clobEncaminhamento, clobRelatorio, ] = result.rows[0];

            const urlReceita = clobReceita ? await clobToBase64(clobReceita) : null;
            const urlAtestado = clobAtestado ? await clobToBase64(clobAtestado) : null;
            const urlExame = clobExame ? await clobToBase64(clobExame) : null;
            const urlEncaminhamento = clobEncaminhamento ? await clobToBase64(clobEncaminhamento) : null;
            const urlRelatorio = clobRelatorio ? await clobToBase64(clobRelatorio) : null;

            return {
                cdAtendimento,
                urlReceita,
                urlAtestado,
                urlExame,
                urlEncaminhamento,
                urlRelatorio
            };
        } else {
            return {
                cdAtendimento,
                urlReceita: null,
                urlAtestado: null,
                urlExame: null,
                urlEncaminhamento: null,
                urlRelatorio: null
            };
        }
    } catch (error) {
        console.error('Erro ao buscar URLs:', error.message);
        return false;
    }
}

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});