const express = require('express');
const jwt = require('jsonwebtoken');
const oracledb = require('oracledb');
const axios = require('axios');
const cors = require('cors');

const app = express();
const port = 3000;

oracledb.initOracleClient({ libDir: '/opt/oracle/instantclient_19_19' });
app.use(cors());

app.use(express.static('public'));

const dbConfig = {
    user: 'dbamv',
    password: 'mvtreina',
    connectString: 'srvdb-hml.sabara.local:1521/pdbtrnmv'
};

//INTEGRAÇÃO INOVAPAR
app.get('/integration1/:document', async (req, res) => {
    let token = req.headers['authorization'];
    const documentNumber = req.params.document; 

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    const isValid = await validateToken(token);
    if (isValid) {
        if (token.startsWith('Bearer ')) {
            token = token.slice(7, token.length).trim();
        }

        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentResponsaNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);

            const cdPacienteResult = await findCdPaciente(connection, documentNumber);

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];

                await findUrl(connection, cdPaciente, res);
            } else if (cdPacienteResult.length === 0) {
                console.log('Document responsa:', documentResponsaNumber);
                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, documentResponsaNumber);
                
                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult[0][0];

                    const cdPacienteResult = await findCdPacienteAtendimento(connection, cdAtendimento);

                    if (cdPacienteResult.length > 0) {
                        const cdPaciente = cdPacienteResult[0][0];

                        await findUrl(connection, cdPaciente, res);
                    } else {
                        return res.status(404).send('Paciente não encontrado para o atendimento fornecido');
                    }
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } else {
        return res.status(401).send('Token inválido');
    }
});

//INTEGRAÇÃO NILO
app.get('/integration2/:document', async (req, res) => {
    let token = req.headers['authorization'];
    const documentNumber = req.params.document; 

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    const isValid = await validateToken(token);
    if (isValid) {
        if (token.startsWith('Bearer ')) {
            token = token.slice(7, token.length).trim();
        }
        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentResponsaNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);

            const cdPacienteResult = await findCdPaciente(connection, documentNumber);

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];

                await findUrlNilo(connection, cdPaciente, res);
            } else if (cdPacienteResult.length === 0) {
                console.log('Document responsa:', documentResponsaNumber);
                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, documentResponsaNumber);
                
                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult[0][0];

                    const cdPacienteResult = await findCdPacienteAtendimento(connection, cdAtendimento);

                    if (cdPacienteResult.length > 0) {
                        const cdPaciente = cdPacienteResult[0][0];

                        await findUrlNilo(connection, cdPaciente, res);
                    } else {
                        return res.status(404).send('Paciente não encontrado para o atendimento fornecido');
                    }
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } else {
        return res.status(401).send('Token inválido');
    }
});

//INTEGRAÇÃO MEVO
app.get('/mevo', async (req, res) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    const isValid = await validateToken(token);
    if (isValid) {
        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);

            const cdPacienteResult = await findCdPacienteId(connection, "0");

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];
                
                const cdAtendimento = await findCdAtendimento(connection, cdPaciente);

                if (cdAtendimento.length > 0) {
                    const atendimentos = cdAtendimento.map(row => row[0]);

                    const urls = [];
                    for (const cdAtendimento of atendimentos) {
                        const urlResult = await findUrlList(connection, cdAtendimento);
                        if (urlResult) {
                            urls.push(urlResult);
                        }
                    }
                    if (urls.length > 0) {
                        return res.json(urls);
                    } else {
                        return res.status(404).send('URLs não encontradas');
                    }
                } 
            } else if (cdPacienteResult.length === 0) {

                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, "32463075805");

                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult;

                    if (cdAtendimento.length > 0) {
                        const atendimentos = cdAtendimento.map(row => row[0]);
    
                        const urls = [];
                        for (const cdAtendimento of atendimentos) {
                            const urlResult = await findUrlList(connection, cdAtendimento);
                            if (urlResult) {
                                urls.push(urlResult);
                            }
                        }
                        if (urls.length > 0) {
                            return res.json(urls);
                        } else {
                            return res.status(404).send('URLs não encontradas');
                        }
                    }                    
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
                           
            
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } else {
        return res.status(401).send('Token inválido');
    }
});

app.get('/mevo/mostrar-pdf/:cdAtendimento', async (req, res) => {
    const { cdAtendimento } = req.params;
    try {
        const connection = await oracledb.getConnection(dbConfig);

        const urlList = await findUrlList(connection, cdAtendimento);

        if (urlList.urlReceita) {
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', 'inline; filename="document.pdf"');
            
            res.send(urlList.urlReceita); 
        } else {
            res.status(404).send('PDF não encontrado');
        }
    } catch (error) {
        res.status(500).send('Erro ao processar o PDF');
        console.error(error);
    }
});

app.get('/mevo/listatendimentos', async (req, res) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    const isValid = await validateToken(token);
    if (isValid) {
        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);

            const cdPacienteResult = await findCdPacienteId(connection, "0");

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];
                const cdAtendimento = await findCdAtendimento(connection, cdPaciente);

                if (cdAtendimento.length > 0) {
                    const atendimentos = cdAtendimento.map(row => ({
                        cdAtendimento: row[0], 
                        dtAtendimento: row[1]
                    }));
                    
                    return res.json(atendimentos);
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            } else {
                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, "32463075805");

                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult;

                    if (cdAtendimento.length > 0) {

                        const atendime = await findCdAtendimentoAndData(connection, cdAtendimento[0][0])

                        const atendimentos = cdAtendimento.map(row => ({
                            cdAtendimento: row[0], 
                            dtAtendimento: row[1]

                        }));
                        
                        return res.json(atendimentos);
                    } else {
                        return res.status(404).send('Atendimento não encontrado');
                    }
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } else {
        return res.status(401).send('Token inválido');
    }
});

app.get('/mevo/listaatendimentos', async (req, res) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(400).send('Token não fornecido');
    }

    try {
        const isValid = await validateToken(token);
        if (!isValid) {
            return res.status(401).send('Token inválido');
        }

        const decodedToken = jwt.decode(token);
        console.log('Decoded Token Payload:', decodedToken);
        const documentNumber = decodedToken.documentNumber;

        let connection;
        try {
            connection = await oracledb.getConnection(dbConfig);

            const cdPacienteResult = await findCdPacienteId(connection, "577905");

            if (cdPacienteResult.length > 0) {
                const cdPaciente = cdPacienteResult[0][0];
                const cdAtendimento = await findCdAtendimentoAndData(connection, cdPaciente);

                if (cdAtendimento.length > 0) {
                    const atendimentos = cdAtendimento.map(row => ({
                        cdAtendimento: row[0],
                        dtAtendimento: row[1]
                    }));

                    return res.json(atendimentos);
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            } else {
                const cdAtendimentoResult = await findCdAtendimentoResponsa(connection, "32463075805");

                if (cdAtendimentoResult && cdAtendimentoResult.length > 0) {
                    const cdAtendimento = cdAtendimentoResult[0][0]; 

                    const atendime = await findCdAtendimentoAndData(connection, cdAtendimento);

                    const atendimentos = atendime.map(row => ({
                        cdAtendimento: row[0],
                        dtAtendimento: row[1]
                    }));

                    return res.json(atendimentos);
                } else {
                    return res.status(404).send('Atendimento não encontrado');
                }
            }
        } catch (err) {
            console.error('Erro ao consultar o banco de dados:', err);
            return res.status(500).send('Erro ao consultar o banco de dados');
        } finally {
            if (connection) {
                try {
                    await connection.close();
                } catch (err) {
                    console.error('Erro ao fechar a conexão com o banco de dados:', err);
                }
            }
        }
    } catch (err) {
        console.error('Erro ao validar o token:', err);
        return res.status(401).send('Token inválido');
    }
});

async function validateToken(token) {
    try {
        const response = await axios.get('https://prod.globalhealth.mv/uaa/validate/token', {
            headers: {
                'Authorization': `${token}`
            }
        });
        return response.status === 204;
    } catch (error) {
        console.error('Erro na validação do token:', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdPacienteId(connection, cdPaciente) {
    const sqlPaciente = 'SELECT CD_PACIENTE FROM PACIENTE WHERE CD_PACIENTE = :cdPaciente';
    console.log('Executing SQL:', sqlPaciente);

    const resultPaciente = await connection.execute(sqlPaciente, { cdPaciente });
    console.log('Query Result:', resultPaciente.rows);

    return resultPaciente.rows;
}

async function findCdAtendimentoResponsa(connection, nrCpf) {
    try {
        const sqlParents = 'SELECT CD_ATENDIMENTO FROM RESPONSA WHERE nr_cpf = :nrCpf';
        console.log('Executing SQL:', sqlParents);

        const resultParents = await connection.execute(sqlParents, { nrCpf });
        console.log('Query Result:', resultParents.rows);

        return resultParents.rows;
    } catch (error) {
        console.error('Erro na validação do token:', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdPacienteAtendimento(connection, cdAtendimento) {
    try {
        const sqlCdPacienteAtendimento = 'SELECT CD_PACIENTE FROM ATENDIME WHERE CD_ATENDIMENTO = :cdAtendimento';
        console.log('Executing SQL:', sqlCdPacienteAtendimento, { cdAtendimento });

        const resultCdAtendimento = await connection.execute(sqlCdPacienteAtendimento, { cdAtendimento });
        console.log('Query Result:', resultCdAtendimento.rows);

        return resultCdAtendimento.rows;
    } catch (error) {
        console.error('Paciente não encontrado!', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdPaciente(connection, nrCpf) {
    try {
        const sqlParents = 'SELECT CD_PACIENTE FROM PACIENTE WHERE nr_cpf = :nrCpf';
        console.log('Executing SQL:', sqlParents, { nrCpf });

        const resultParents = await connection.execute(sqlParents, { nrCpf });
        console.log('Query Result:', resultParents.rows);

        return resultParents.rows;
    } catch (error) {
        console.error('Paciente não encontrado!', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdAtendimento(connection, cdPaciente) {
    try {
        const sqlCdAtendimento = 'SELECT CD_ATENDIMENTO FROM ATENDIME WHERE CD_PACIENTE = :cdPaciente';
        console.log('Executing SQL:', sqlParents, { cdPaciente });

        const resultCdAtendimentos = await connection.execute(sqlCdAtendimento, {cdPaciente});
        console.log('Query Result:', resultCdAtendimentos.rows);

        return resultCdAtendimentos.rows;
    } catch (error) {
        console.error('Paciente não encontrado!', error.response ? error.response.data : error.message);
        return false;
    }
}

async function findCdAtendimentoAndData(connection, cdPaciente) {
    try {
        const sqlcdAtendimentoAndData = 'SELECT CD_ATENDIMENTO, DT_ATENDIMENTO FROM ATENDIME WHERE CD_PACIENTE = :cdPaciente';
        console.log('Executing SQL:', sqlcdAtendimentoAndData, { cdPaciente });

        const resultCdAtendimentoAndData = await connection.execute(sqlcdAtendimentoAndData, { cdPaciente });
        console.log('Query Result:', resultCdAtendimentoAndData.rows);

        return resultCdAtendimentoAndData.rows;
    } catch (error) {
        console.error('Erro ao buscar atendimentos:', error.message);
        return false;
    }
}

async function findUrlNilo(connection, cdPaciente, res) {
    try {
        const sql = `
            SELECT * 
            FROM DBAMV.PW_CASO_PROTOCOLO 
            WHERE CD_ALERTA_PROTOCOLO IN (81, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112)
            AND CD_PACIENTE = :cdPaciente`;
        console.log('Executing SQL:', sql);

        const result = await connection.execute(sql, { cdPaciente });
        console.log('Query Result:', result.rows);

        if (result.rows.length > 0) {

            const url = `https://stg.nilosaude.app/agenda/%7B%7BidPaciente%7D%7D/agendar?selected=true&embedded=true`;

            return res.json({ url });
        } else {
            return res.status(404).send('Recurso não disponível no momento para o seu perfil');
        }
    } catch (error) {
        console.error('Erro ao buscar URL:', error.message);
        return res.status(500).send('Erro ao buscar URL');
    }
}


async function findUrl(connection, cdPaciente, res) {
    try {
        const sql2 = `
            SELECT CD_PACIENTE, TO_CHAR(DT_ATENDIMENTO, 'dd') || TO_CHAR(DT_ATENDIMENTO, 'MM') || TO_CHAR(DT_ATENDIMENTO, 'RRRR') || CD_ATENDIMENTO AS senha 
            FROM atendime WHERE CD_PACIENTE = :cdPaciente
        `;
        console.log('Executing SQL:', sql2);

        const result2 = await connection.execute(sql2, { cdPaciente });
        console.log('Query Result:', result2.rows);

        if (result2.rows.length > 0) {
            const firstResult = result2.rows[0];
            const senha = firstResult[1];

            const url = `https://resultadosdeexames.sabara.com.br/vedocs/public/laudo.action?protocolo=${cdPaciente}&senha=${senha}&origem=1&acessoExterno=true`;

            return res.json({ url });
        } else {
            return res.status(404).send('Dados não encontrados para o paciente');
        }
    } catch (error) {
        console.error('Erro ao buscar URL:', error.message);
        return res.status(500).send('Erro ao buscar URL');
    }
}

async function clobToBase64(clob) {
    return new Promise((resolve, reject) => {
        if (clob === null) {
            resolve(null);
        }

        let clobData = '';
        clob.setEncoding('utf8'); 

        clob.on('data', (chunk) => {
            clobData += chunk; 
        });

        clob.on('end', () => {
            resolve(clobData); 
        });

        clob.on('error', (err) => {
            reject(err);
        });
    });
}

async function findUrlList(connection, cdAtendimento) {
    try {
        const sqlUrlList = 'SELECT PDF_RETORNO_RECEITA, PDF_RETORNO_ATESTADO, PDF_RETORNO_EXAME, PDF_RETORNO_ENCAMINHAMENTO, PDF_RETORNO_RELATORIO ' +
            'FROM nexodata.PRESC_NEXODATA WHERE CD_ATENDIMENTO = :cdAtendimento';
        console.log('Executing SQL:', sqlUrlList, { cdAtendimento });

        const result = await connection.execute(sqlUrlList, { cdAtendimento });
        console.log('Query Result:', result.rows);

        if (result.rows.length > 0) {
            let [clobReceita, clobAtestado, clobExame, clobEncaminhamento, clobRelatorio] = result.rows[0];

            const urlReceita = clobReceita ? await clobToBase64(clobReceita) : null;
            const urlAtestado = clobAtestado ? await clobToBase64(clobAtestado) : null;
            const urlExame = clobExame ? await clobToBase64(clobExame) : null;
            const urlEncaminhamento = clobEncaminhamento ? await clobToBase64(clobEncaminhamento) : null;
            const urlRelatorio = clobRelatorio ? await clobToBase64(clobRelatorio) : null;

            const decodedReceita = urlReceita ? Buffer.from(urlReceita, 'base64') : null;
            const decodedAtestado = urlAtestado ? Buffer.from(urlAtestado, 'base64') : null;
            const decodedExame = urlExame ? Buffer.from(urlExame, 'base64') : null;
            const decodedEncaminhamento = urlEncaminhamento ? Buffer.from(urlEncaminhamento, 'base64') : null;
            const decodedRelatorio = urlRelatorio ? Buffer.from(urlRelatorio, 'base64') : null;

            return {
                cdAtendimento,
                urlReceita: decodedReceita,
                urlAtestado: decodedAtestado,
                urlExame: decodedExame,
                urlEncaminhamento: decodedEncaminhamento,
                urlRelatorio: decodedRelatorio
            };
        } else {
            return {
                cdAtendimento,
                urlReceita: null,
                urlAtestado: null,
                urlExame: null,
                urlEncaminhamento: null,
                urlRelatorio: null
            };
        }
    } catch (error) {
        console.error('Erro ao buscar URLs:', error.message);
        return false;
    }
}


app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});

