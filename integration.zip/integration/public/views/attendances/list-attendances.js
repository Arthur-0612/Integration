const pdfjsLib = window['pdfjs-dist/build/pdf'];
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.11.338/pdf.worker.min.js';

async function getAttendances() {
    const loading = document.querySelector('.backdrop__container');

    try {
        loading.classList.add('backdrop__container__show');

        const response = await fetch('http://srv-app-integra.sabara.com.br:3000/integration3/listaatendimentos', {
            method: 'GET',
            headers: {
                'Authorization': globalVariables.token,
            }
        });

        if (!response.ok) {
            const errorMessage = `Erro angelo ${response.status}: ${response.statusText}`;
            throw new Error(errorMessage);
        }

        const attendanceUrl = await response.json();
        renderListView(attendanceUrl);

    } catch (error) {
        loading.classList.remove('backdrop__container__show');
        listView.innerHTML = '<span class="text-muted ps-0">Sem registros de atendimentos.</span>';
        console.error('Erro ao buscar atendimentos:', error);
    }
}

function renderListView(items) {
    items.forEach(attendanceItem => {
        const formattedDate = formatDate(attendanceItem.dtAtendimento);

        const bsGridItem = document.createElement('li');
        bsGridItem.className = 'col-12 col-md-6 col-lg-4';

        const card = document.createElement('div');
        card.className = 'card__attendance';

        const title = document.createElement('h5');
        title.className = 'card__attendance__title';
        title.innerHTML = formattedDate;

        const info = document.createElement('div');
        info.className = 'card__attendance__info';
        info.innerHTML = `<img src="assets/svg/Orion_clipboard.svg" class="icon__clipboard"></img> Nº Atend.: ${attendanceItem.cdAtendimento}`;

        card.addEventListener('click', () => getDocumentAndPreview(attendanceItem));

        card.appendChild(title);
        card.appendChild(info);
        bsGridItem.appendChild(card);

        listView.appendChild(bsGridItem);
    });
}

async function getDocumentAndPreview(attendanceItem) {
    const loading = document.querySelector('.backdrop__container');

    let modalShowDocuments = document.createElement('div');
    const viewExamsPath = 'views/shared/shared-modal.html';
    fetch(viewExamsPath)
        .then((response) => response.text())
        .then((html) => {
            modalShowDocuments.innerHTML = html
            document.body.appendChild(modalShowDocuments);
        })

    try {
        loading.classList.add('backdrop__container__show')

        const cdAtendimento = attendanceItem.cdAtendimento;

        const response = await fetch(`http://srv-app-integra.sabara.com.br:3000/integration3/mostrar-pdf/${cdAtendimento}`, {
            method: 'GET'
        });

        if (!response.ok) {
            throw new Error('Erro ao buscar documentos');
        }

        loading.classList.remove('backdrop__container__show');

        const canvas = document.getElementById('pdf-canvas');
        const context = canvas.getContext('2d');

        const blob = await response.blob();
        const fileReader = new FileReader();
        fileReader.onload = function () {
            const typedarray = new Uint8Array(this.result);
            pdfjsLib.getDocument(typedarray).promise.then(pdf => {
                pdf.getPage(1).then(page => {
                    const viewport = page.getViewport({scale: 1.5});
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;

                    const renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };
                    page.render(renderContext);
                });
            });
        };
        fileReader.readAsArrayBuffer(blob);

        const downloadButton = document.getElementById('downloadButton');
        const blobUrl = URL.createObjectURL(blob);
        downloadButton.href = blobUrl;
        downloadButton.download = `document-${new Date().getTime()}.pdf`;

        const modalElement = document.getElementById('pdfModal');
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
        modalElement.addEventListener('hidden.bs.modal', () => {
            document.body.removeChild(modalShowDocuments);
        });
    } catch (error) {
        loading.classList.remove('backdrop__container__show');
        console.error('Erro ao buscar documentos:', error);
        document.body.removeChild(modalShowDocuments);
        showError();
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);

    if (isNaN(date.getTime())) {
        return '-'
    }

    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = String(date.getFullYear()).slice(-2);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');

    return `${day}/${month}/${year} - ${hours}:${minutes}`;
}

function showError() {
    let modalShowDocuments = document.createElement('div');
    const viewExamsPath = 'views/shared/toast-error.html';

    fetch(viewExamsPath)
        .then((response) => response.text())
        .then((html) => {
            modalShowDocuments.innerHTML = html;
            document.body.appendChild(modalShowDocuments);

            let toastEl = modalShowDocuments.querySelector('#errorToast');
            let toast = new bootstrap.Toast(toastEl);

            toastEl.addEventListener('hidden.bs.toast', function () {
                document.body.removeChild(modalShowDocuments)
            });

            toast.show(); // Mostra o toast
        });
}

initTokenConfig();
